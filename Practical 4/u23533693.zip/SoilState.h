#ifndef	SOILSTATE_H
#define SOILSTATE_H
#include "CropField.h"
#include <iostream>
using namespace std;

class CropField;
class SoilState
{
public:
	virtual void harvestCrops(FarmUnit* field) = 0;
	virtual void rain(FarmUnit* field) = 0;
	virtual string getName() = 0;
};
#endif /*SOILSTATE_H*/

