#include "Barn.h"
int Barn::getTotalCapacity() const {
	return totalCapacity;
}
